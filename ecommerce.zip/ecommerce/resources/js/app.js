require('./bootstrap');

funct() {
    alert("this shoud");
}