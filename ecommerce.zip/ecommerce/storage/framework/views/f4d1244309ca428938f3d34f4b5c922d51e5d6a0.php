
<?php $__env->startSection('content'); ?>



<h1>welcome to MEnProducts page <?php echo e(session()->get('username')); ?></h1>


<div class="allproducts">
<?php $__currentLoopData = $allwomen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="item <?php echo e($item->id==1?'active':''); ?>" style="float:left" >

    
    <div class="card">
    
    <a href="detailsofeachproduct/<?php echo e($item->id); ?>">

      <img src="<?php echo e($item->gallery); ?>" alt="Los Angeles">
    <div class="card-body">
      <h4 class="card-title"><?php echo e($item->name); ?></h4>
      <h5 class="card-text"><?php echo e($item->productname); ?></h5>
      </a>
    </div>
  </div>
      </div>

      
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <br><br>
   
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel_projects\ecommerce\resources\views/women.blade.php ENDPATH**/ ?>