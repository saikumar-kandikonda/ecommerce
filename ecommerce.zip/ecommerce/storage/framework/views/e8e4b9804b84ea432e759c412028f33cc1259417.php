
<?php $__env->startSection('content'); ?>



<?php
$totalprice=0
?>
<div class="usercart">
    <?php if($usercart->count()>=1): ?>
    
    <a href="/ordernow"><button class="btn btn-success" id="ordernowbutton">ORDER NOW</button></a>
<?php else: ?>

<?php endif; ?>
    <br><br><br>
    
   
<?php $__currentLoopData = $usercart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<div class="row searched-item cart-list-divider">

             <div class="col-sm-3">
             <a href="detailsofeachproduct/<?php echo e($item->id); ?>">
                    <img class="trending-image" src="<?php echo e($item->gallery); ?>" >
                  </a>
             </div>
             <div class="col-sm-2">
                    <div class="">
                      <h1><?php echo e($item->name); ?></h1>
                      <h4><?php echo e($item->description); ?></h4>
                    </div>
             </div>
             <div class="col-sm-1">
            PRICE: <h3> <?php echo e($item->price); ?></h3>
             </div>
             <div class="col-sm-1">
             <a href="/removecart/<?php echo e($item->cartid); ?>" class="btn btn-danger" >Remove From Cart&nbsp;<span class="glyphicon glyphicon-remove"></span></a>
             </div>
            </div>
            <br><br>
          <input type="hidden" value="<?php echo e($totalprice+=$item->price); ?>">  
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
    <div class="totalbutton">
      
    TOTAL PRICE IS <?php echo e($totalprice); ?><br> </div>


   
      
   

<?php $__env->stopSection(); ?>
</div>
</div>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel_projects\ecommerce\resources\views/usercart.blade.php ENDPATH**/ ?>