
<?php $__env->startSection('content'); ?>

<div class="containerlogin">
<form action="register" method="post">

<div class="col-sm-6">
<div class="form-group">
    <label for="exampleInputEmail1">Name</label>
    <input type="text" class="form-control" name="name" id="name"  placeholder="Enter your full name">
  </div>

  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="text" class="form-control" name="email" id="email"  placeholder="Enter email">
   
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" name="password"id="password" placeholder="Password">
  </div>
  <!-- <div class="form-group">
    <label for="exampleInputPassword2">RE-enter Password</label>
    <input type="password" class="form-control" name="repassword" id="repassword" placeholder="Re-enter Password">
  </div><br> -->
  <?php echo csrf_field(); ?><br><br>
  <button type="submit" class="btn btn-primary">Register</button>
  </div>
</form>


<?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel_projects\ecommerce\resources\views/Register.blade.php ENDPATH**/ ?>