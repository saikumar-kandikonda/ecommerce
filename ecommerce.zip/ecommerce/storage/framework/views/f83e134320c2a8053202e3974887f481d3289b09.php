<!-- <br><br>

<footer>all copyrights @moxies
</footer> -->
<?php /**PATH C:\wamp64\www\laravel_projects\ecommerce\resources\views/footer.blade.php ENDPATH**/ ?>