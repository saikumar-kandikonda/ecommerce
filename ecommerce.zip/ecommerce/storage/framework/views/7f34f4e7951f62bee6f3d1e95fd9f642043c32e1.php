
<?php $__env->startSection('content'); ?>
<h1>welcome to homepage</h1>
<h1>this is the body section of the layout</h1>
<button class="btn btn-danger" id="clickme">click me to fuck</button>
<div id="texthere">this will be toggled</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel_projects\ecommerce\resources\views/home.blade.php ENDPATH**/ ?>