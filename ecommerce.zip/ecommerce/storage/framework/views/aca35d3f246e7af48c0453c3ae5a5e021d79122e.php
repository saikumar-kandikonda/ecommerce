
<?php $__env->startSection('content'); ?>
<h1>Your wishlist  <?php echo e(session()->get('username')); ?></h1>

<br>

    
    
    <br>
    <div class="usercart">
<?php $__currentLoopData = $usercart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="row searched-item cart-list-devider">
             <div class="col-sm-3">
             <a href="detailsofeachproduct/<?php echo e($item->id); ?>">
                    <img class="trending-image" src="<?php echo e($item->gallery); ?>" width=200px height=200px>
                    </a>
             </div>
             <div class="col-sm-3">
                    <div class="">
                    <a href="detailsofeachproduct/<?php echo e($item->id); ?>">
                      <h2><?php echo e($item->name); ?></h2>
                      </a>
                    </div>
             </div>
             
             <div class="col-sm-1">
             PRICE: <h3> <?php echo e($item->price); ?></h3>
             </div>
           
             <div class="col-sm-1">
             <form action="/addtocart" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="productid" value="<?php echo e($item->id); ?>">
            <button class="btn btn-success"><span class="glyphicon glyphicon-shopping-cart"></span>Add to cart</button><br>
            </form> 
             </div>
            </div>
            <br><br>
         
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel_projects\ecommerce\resources\views/wishlist.blade.php ENDPATH**/ ?>